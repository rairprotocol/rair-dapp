'use strict';

const ingest = require('..');

describe('ingest', () => {
    it('needs tests');
});
