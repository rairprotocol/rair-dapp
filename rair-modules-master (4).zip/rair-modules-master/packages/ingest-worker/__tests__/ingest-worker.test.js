'use strict';

const ingestWorker = require('..');

describe('ingest-worker', () => {
    it('needs tests');
});
