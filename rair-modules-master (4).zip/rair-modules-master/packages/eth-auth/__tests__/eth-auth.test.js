'use strict';

const ethAuth = require('..');

describe('@rair/eth-auth', () => {
    it('needs tests');
});
